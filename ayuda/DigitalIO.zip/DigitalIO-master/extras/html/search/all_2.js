var searchData=
[
  ['config',['config',['../class_digital_pin.html#aa6e07eea6e152d47c6f0d232bed9c45e',1,'DigitalPin::config()'],['../group__runtime_digital.html#gaa6f8f81ccea9ba7813f37748252bacb4',1,'PinIO::config()']]]
];
